import {Product} from "./product";

export class Order {
  // private _product?: Product;
  private _email?: string;
  // private _totalCost?: number;

}
