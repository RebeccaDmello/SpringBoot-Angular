import { ProductOrders } from './product-orders.model';

describe('ProductOrders', () => {
  it('should create an instance', () => {
    expect(new ProductOrders()).toBeTruthy();
  });
});
