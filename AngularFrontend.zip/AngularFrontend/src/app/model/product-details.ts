import {Product} from "./product";

export class ProductDetails {

  product!: Product;
  quantity!: number;
  email!: string;
}
