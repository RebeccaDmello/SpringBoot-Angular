export class Subcategory {
    scid?:number;
    scname?:string;
}
