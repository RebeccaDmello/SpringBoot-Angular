import {ProductDetails} from "./product-details";

export class ProductOrders {
  productOrders: ProductDetails[] = [];
}
