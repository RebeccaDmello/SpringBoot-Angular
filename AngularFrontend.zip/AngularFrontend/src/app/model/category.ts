import { Subcategory } from "./subcategory";

export class Category {
    cid?:number;
    cname?:string;
    csub?:Array<Subcategory>;
}
