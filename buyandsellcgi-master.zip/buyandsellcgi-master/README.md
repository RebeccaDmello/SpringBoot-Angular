# buyandsellcgi

Buying and Selling products platform developed using technologies like SpringBoot and Angular