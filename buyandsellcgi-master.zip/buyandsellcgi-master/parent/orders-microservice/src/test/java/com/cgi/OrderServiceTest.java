package com.cgi;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cgi.repository.OrderRepository;
import com.cgi.service.OrderService;

@SpringBootTest
public class OrderServiceTest {

//	@Mock
//	private OrderRepository orderRepo;
//	
//	@InjectMocks
//	private OrderService ordServe;
//	
//	@Before
//	public void setup() {
//		MockitoAnnotations.initMocks(this);
//	}
	
	
//	@Test
//	public void addOrderSuccess() throws Exception{
//		
//	}
}
