package com.cgi.ampqservice.model;

public record UserDto (
        String name,
        String email,
        String token){


}
