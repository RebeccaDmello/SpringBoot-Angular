package com.cgi.accountservice.exceptions;

public class EmailAndUsernameExists extends Exception{
	
	public EmailAndUsernameExists(String message) {
		super(message);
	}

}
