package com.cgi.accountservice.exceptions;

public class UsernameAlreadyExistsException extends Exception{
	
	public UsernameAlreadyExistsException(String message) {
		super(message);
	}

}
