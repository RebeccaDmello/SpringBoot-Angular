package com.cgi.accountservice.exceptions;

public class EmailAlreadyExistsException extends Exception {
	
	public EmailAlreadyExistsException(String message) {
		super(message);
	}

}
