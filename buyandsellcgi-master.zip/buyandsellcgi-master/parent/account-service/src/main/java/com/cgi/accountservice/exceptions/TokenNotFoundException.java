package com.cgi.accountservice.exceptions;

public class TokenNotFoundException extends Exception{
	
	public TokenNotFoundException(String message) {
		super(message);
	}

}
