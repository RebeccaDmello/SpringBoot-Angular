package com.cgi.accountservice.exceptions;

public class EmailAlreadyConfirmedException extends Exception{
	
	public EmailAlreadyConfirmedException(String message) {
		super(message);
	}

}
