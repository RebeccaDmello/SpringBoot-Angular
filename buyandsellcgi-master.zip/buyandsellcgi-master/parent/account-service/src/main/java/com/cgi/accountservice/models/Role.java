package com.cgi.accountservice.models;

public enum Role {
	ADMIN,
	USER
}
